# University Portal API: foundation slice

NestJS modular monolith + PostgreSQL + Redis. This slice implements the **hot, correctness-critical paths** from
the TRD (Sections 1-2): course registration with concurrency control, the append-only grade workflow, multi-campus
Row-Level Security, the transactional outbox, audit logging, and OIDC auth.

> **Status: not yet compiled or run.** It was written without network access, so dependencies could not be
> installed and the SQL could not be executed against a live Postgres. A syntax-only TypeScript parse is clean.
> Expect to fix a few type/SQL nits on first `npm run typecheck` / first boot. See "First-run checklist".

## Run it

```bash
cp .env.example .env
docker compose up -d            # Postgres (runs db/001_init.sql + db/002_seed.sql on first boot) + Redis
npm install
npm run start:dev               # http://localhost:3000
```

`DEV_AUTH=true` lets you authenticate with an `x-dev-sub` header instead of a JWT (ignored in production).
Seed users: `student-1..3`, `faculty-1`, `registrar-1`, `depthead-1`.

## Demo walkthrough

```bash
S=a0000000-0000-7000-8000-000000000001   # CSC-101, capacity 2, waitlist 1
H='-H Content-Type:application/json'

# students 1 and 2 get seats, student 3 is waitlisted (position 1)
curl -s $H -H 'x-dev-sub: student-1' -H 'Idempotency-Key: k1' -d "{\"sectionId\":\"$S\"}" localhost:3000/v1/registrations
curl -s $H -H 'x-dev-sub: student-2' -H 'Idempotency-Key: k2' -d "{\"sectionId\":\"$S\"}" localhost:3000/v1/registrations
curl -s $H -H 'x-dev-sub: student-3' -H 'Idempotency-Key: k3' -d "{\"sectionId\":\"$S\"}" localhost:3000/v1/registrations

# replay with the same key -> same result, "replayed": true
curl -s $H -H 'x-dev-sub: student-1' -H 'Idempotency-Key: k1' -d "{\"sectionId\":\"$S\"}" localhost:3000/v1/registrations

curl -s -H 'x-dev-sub: student-1' localhost:3000/v1/sections/$S/availability

# student-1 drops -> student-3 is auto-promoted (WaitlistPromoted event in the outbox log)
curl -s -X DELETE -H 'x-dev-sub: student-1' localhost:3000/v1/registrations/<enrollmentId>
```

Grade flow (flip the term to `grading` is not enforced yet, see gaps):
`faculty-1` POST `/v1/sections/:id/grades` → `depthead-1` POST `/grades/approve` → `registrar-1` POST `/grades/post`
→ `registrar-1` POST `/v1/enrollments/:id/grades/amend` (reason required) → approve → post.

## Why registration is race-free

1. **Redis seat gate** (`seat-gate.ts`): atomic Lua counter sheds excess load before it reaches Postgres. It is a
   *filter*: TTL'd, invalidated on drops, and **fails open** if Redis is down.
2. **Guarded single-statement UPDATE** (`registration.service.ts`):
   `UPDATE sections SET enrolled_count = enrolled_count + 1 WHERE id = $1 AND enrolled_count < capacity`.
   Row-level atomicity gives exactly-`capacity` winners with no explicit locks or retry loops. A `CHECK`
   constraint is the backstop. The waitlist ticket comes from a second guarded update (`waitlist_seq`).
3. **Idempotency**: unique `idempotency_key`; replays return the original outcome, concurrent duplicates
   resolve via the unique-violation handler.
4. **Transactional outbox**: the event commits with the enrollment, so "enrolled but never billed" cannot happen.

## Layout

```
db/001_init.sql          schema, enums, uuidv7, RLS policies, immutability triggers, app role
db/002_seed.sql          dev seed
src/common/              db tx helper (RLS session vars), auth (OIDC/JWKS), RBAC policy, audit + outbox helpers
src/registration/        enroll / drop+withdraw / waitlist promotion / schedule / availability
src/grading/             submit → approve → post → amend (append-only chain)
src/outbox/              relay (SKIP LOCKED) + Log/SQS publishers
load/register.k6.js      spike test
```

## First-run checklist

- `npm run typecheck` and fix any type nits.
- Connect as `portal_app`, **never** the owner/superuser, or RLS is bypassed.
- Verify no oversell: after the k6 run, `SELECT enrolled_count, capacity FROM sections;` and compare against
  `SELECT count(*) FROM enrollments WHERE status='enrolled' GROUP BY section_id;`.

## Known gaps (deliberately not built yet)

- **RBAC/ABAC matrix** (`src/common/policy.ts`) is a placeholder until TRD Section 3 is finalized.
- Term-status guards for grading (only allow submit in `active`/`grading`, post in `grading`).
- Waitlist promotion doesn't re-check holds/schedule conflicts for the promoted student, and has no offer window.
- Credit-load limits, corequisites, and degree audit.
- Event **consumers**: billing charge on `EnrollmentConfirmed`, GPA projection on `GradePosted`, notifications.
- Billing/payments module, holds management API, faculty attendance/syllabus/office hours, PDF/transcript worker,
  notification gateway (WebSocket/email/SMS), LMS (LTI 1.3/Canvas) adapter, announcements.
- Next.js frontend, Terraform/ECS infrastructure, CI/CD, `pg_partman` for `audit_log`, outbox retention job,
  Redis invalidation of cached permissions when `role_assignments` change.
- Per-student FERPA audit rows for bulk grade operations (currently one audit row per batch).
