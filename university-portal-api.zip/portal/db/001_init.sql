-- University Portal: core schema (PostgreSQL 16)
-- Run as the owner/superuser. The app connects as portal_app (non-owner) so RLS applies.

CREATE EXTENSION IF NOT EXISTS citext;

-- UUIDv7 (time-ordered) generator. Replace with native uuidv7() on PostgreSQL 18+.
CREATE OR REPLACE FUNCTION uuid_generate_v7() RETURNS uuid AS $$
  SELECT encode(
    set_bit(
      set_bit(
        overlay(uuid_send(gen_random_uuid())
                placing substring(int8send(floor(extract(epoch FROM clock_timestamp()) * 1000)::bigint) FROM 3)
                FROM 1 FOR 6),
        52, 1),
      53, 1),
    'hex')::uuid;
$$ LANGUAGE sql VOLATILE;

-- ───────── Enums ─────────
CREATE TYPE user_status        AS ENUM ('active','suspended','alumni','deactivated');
CREATE TYPE scope_type         AS ENUM ('global','campus','department','section');
CREATE TYPE term_status        AS ENUM ('planning','registration','active','grading','closed');
CREATE TYPE requisite_kind     AS ENUM ('prerequisite','corequisite');
CREATE TYPE section_status     AS ENUM ('draft','open','closed','cancelled');
CREATE TYPE enrollment_status  AS ENUM ('enrolled','waitlisted','dropped','withdrawn','completed');
CREATE TYPE grade_status       AS ENUM ('draft','submitted','approved','posted','rejected');
CREATE TYPE ledger_kind        AS ENUM ('charge','payment','refund','adjustment','waiver');
CREATE TYPE payment_status     AS ENUM ('pending','settled','failed','refunded');
CREATE TYPE hold_type          AS ENUM ('financial','academic','disciplinary','immunization');

-- ───────── Tenancy & identity ─────────
CREATE TABLE campuses (
  id        uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  code      varchar(32)  NOT NULL UNIQUE,
  name      varchar(200) NOT NULL,
  timezone  varchar(64)  NOT NULL
);

CREATE TABLE users (
  id           uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  campus_id    uuid NOT NULL REFERENCES campuses(id),
  idp_subject  varchar(255) NOT NULL UNIQUE,          -- OIDC "sub"
  email        citext NOT NULL UNIQUE,
  status       user_status NOT NULL DEFAULT 'active',
  created_at   timestamptz NOT NULL DEFAULT now(),
  deleted_at   timestamptz
);

CREATE TABLE person_profiles (
  user_id            uuid PRIMARY KEY REFERENCES users(id),
  legal_name         varchar(200) NOT NULL,
  preferred_name     varchar(200),
  date_of_birth_enc  bytea,                            -- encrypt at app layer (KMS envelope)
  phone_enc          bytea,
  directory_opt_out  boolean NOT NULL DEFAULT false    -- FERPA directory-information control
);

-- ───────── Academic structure ─────────
CREATE TABLE departments (
  id                uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  campus_id         uuid NOT NULL REFERENCES campuses(id),
  code              varchar(32)  NOT NULL,
  name              varchar(200) NOT NULL,
  head_employee_id  uuid,                              -- FK added below (circular)
  UNIQUE (campus_id, code)
);

CREATE TABLE programs (
  id                      uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  department_id           uuid NOT NULL REFERENCES departments(id),
  code                    varchar(32)  NOT NULL,
  name                    varchar(200) NOT NULL,
  degree_level            varchar(32),
  total_credits_required  numeric(5,2),
  UNIQUE (department_id, code)
);

CREATE TABLE terms (
  id                      uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  campus_id               uuid NOT NULL REFERENCES campuses(id),
  code                    varchar(16) NOT NULL,        -- e.g. 2026FA
  starts_on               date NOT NULL,
  ends_on                 date NOT NULL,
  registration_opens_at   timestamptz,
  add_deadline            timestamptz,
  drop_deadline           timestamptz,
  withdraw_deadline       timestamptz,
  grades_due_at           timestamptz,
  status                  term_status NOT NULL DEFAULT 'planning',
  UNIQUE (campus_id, code),
  CHECK (ends_on > starts_on)
);

CREATE TABLE students (
  id                 uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  campus_id          uuid NOT NULL REFERENCES campuses(id),
  user_id            uuid NOT NULL UNIQUE REFERENCES users(id),
  student_number     varchar(32) NOT NULL UNIQUE,
  program_id         uuid REFERENCES programs(id),
  admit_term_id      uuid REFERENCES terms(id),
  academic_standing  varchar(32)
);

CREATE TABLE employees (
  id               uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  user_id          uuid NOT NULL UNIQUE REFERENCES users(id),
  employee_number  varchar(32) NOT NULL UNIQUE,
  department_id    uuid REFERENCES departments(id),
  title            varchar(100)
);

ALTER TABLE departments
  ADD CONSTRAINT departments_head_fk FOREIGN KEY (head_employee_id) REFERENCES employees(id);

CREATE TABLE courses (
  id             uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  department_id  uuid NOT NULL REFERENCES departments(id),
  code           varchar(32)  NOT NULL,                -- e.g. CSC-301
  title          varchar(200) NOT NULL,
  credits        numeric(4,2) NOT NULL CHECK (credits > 0),
  description    text,
  active         boolean NOT NULL DEFAULT true,
  UNIQUE (department_id, code)
);

CREATE TABLE course_requisites (
  course_id           uuid NOT NULL REFERENCES courses(id),
  required_course_id  uuid NOT NULL REFERENCES courses(id),
  kind                requisite_kind NOT NULL,
  min_grade           varchar(4),                      -- symbol from grade_scales; NULL = any non-zero grade
  PRIMARY KEY (course_id, required_course_id, kind),
  CHECK (course_id <> required_course_id)
);

CREATE TABLE sections (
  id                 uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  campus_id          uuid NOT NULL REFERENCES campuses(id),
  course_id          uuid NOT NULL REFERENCES courses(id),
  term_id            uuid NOT NULL REFERENCES terms(id),
  section_code       varchar(16) NOT NULL,
  capacity           int NOT NULL CHECK (capacity >= 0),
  enrolled_count     int NOT NULL DEFAULT 0,           -- authoritative; only changed by guarded UPDATEs
  waitlist_capacity  int NOT NULL DEFAULT 0 CHECK (waitlist_capacity >= 0),
  waitlist_count     int NOT NULL DEFAULT 0,           -- current waitlist size
  waitlist_seq       int NOT NULL DEFAULT 0,           -- monotonic ticket; becomes waitlist position
  status             section_status NOT NULL DEFAULT 'draft',
  UNIQUE (course_id, term_id, section_code),
  CHECK (enrolled_count >= 0 AND enrolled_count <= capacity),
  CHECK (waitlist_count >= 0 AND waitlist_count <= waitlist_capacity)
);
CREATE INDEX sections_term_status_idx ON sections (term_id, status);

CREATE TABLE section_instructors (
  section_id   uuid NOT NULL REFERENCES sections(id),
  employee_id  uuid NOT NULL REFERENCES employees(id),
  role         varchar(32) NOT NULL DEFAULT 'primary',
  PRIMARY KEY (section_id, employee_id)
);

CREATE TABLE section_meetings (
  id           uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  section_id   uuid NOT NULL REFERENCES sections(id),
  day_of_week  smallint NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  starts_at    time NOT NULL,
  ends_at      time NOT NULL,
  room         varchar(64),
  CHECK (ends_at > starts_at)
);
CREATE INDEX section_meetings_section_idx ON section_meetings (section_id);

-- ───────── Authorization ─────────
CREATE TABLE roles (
  id          uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  key         varchar(32) NOT NULL UNIQUE,
  scope_type  scope_type NOT NULL
);

CREATE TABLE role_assignments (
  id          uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  user_id     uuid NOT NULL REFERENCES users(id),
  role_id     uuid NOT NULL REFERENCES roles(id),
  scope_id    uuid,                                    -- campus/department/section id per roles.scope_type
  valid_from  timestamptz NOT NULL DEFAULT now(),
  valid_to    timestamptz,
  granted_by  uuid REFERENCES users(id)
);
CREATE INDEX role_assignments_user_idx ON role_assignments (user_id, valid_to);

-- ───────── Enrollment ─────────
CREATE TABLE enrollments (
  id                uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  campus_id         uuid NOT NULL REFERENCES campuses(id),
  student_id        uuid NOT NULL REFERENCES students(id),
  section_id        uuid NOT NULL REFERENCES sections(id),
  term_id           uuid NOT NULL REFERENCES terms(id),
  status            enrollment_status NOT NULL,
  credits_snapshot  numeric(4,2) NOT NULL,
  grade_mode        varchar(16) NOT NULL DEFAULT 'letter',
  idempotency_key   varchar(200) NOT NULL,
  enrolled_at       timestamptz,
  dropped_at        timestamptz,
  version           int NOT NULL DEFAULT 1,
  created_at        timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX enrollments_idem_uq   ON enrollments (idempotency_key);
CREATE UNIQUE INDEX enrollments_active_uq ON enrollments (student_id, section_id)
  WHERE status IN ('enrolled','waitlisted');
CREATE INDEX enrollments_section_idx      ON enrollments (section_id, status);
CREATE INDEX enrollments_student_term_idx ON enrollments (term_id, student_id);

CREATE TABLE waitlist_entries (
  id             uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  section_id     uuid NOT NULL REFERENCES sections(id),
  student_id     uuid NOT NULL REFERENCES students(id),
  enrollment_id  uuid NOT NULL UNIQUE REFERENCES enrollments(id),
  position       int NOT NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (section_id, position)
);

-- ───────── Grading (append-only chain) ─────────
CREATE TABLE grade_scales (
  symbol         varchar(4) PRIMARY KEY,
  points         numeric(3,2) NOT NULL,
  counts_in_gpa  boolean NOT NULL DEFAULT true
);

CREATE TABLE grade_entries (
  id               uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  enrollment_id    uuid NOT NULL REFERENCES enrollments(id),
  symbol           varchar(4) NOT NULL REFERENCES grade_scales(symbol),
  points_snapshot  numeric(3,2) NOT NULL,
  status           grade_status NOT NULL,
  supersedes_id    uuid REFERENCES grade_entries(id),
  submitted_by     uuid NOT NULL REFERENCES users(id),
  approved_by      uuid REFERENCES users(id),
  reason           text,
  created_at       timestamptz NOT NULL DEFAULT now()
);
-- At most ONE successor per entry: this is what makes concurrent approvals/posts race-safe.
CREATE UNIQUE INDEX grade_entries_successor_uq ON grade_entries (supersedes_id) WHERE supersedes_id IS NOT NULL;
CREATE UNIQUE INDEX grade_entries_root_uq ON grade_entries (enrollment_id) WHERE supersedes_id IS NULL;
CREATE INDEX grade_entries_enrollment_idx ON grade_entries (enrollment_id, status, created_at DESC);

-- Official grade = latest POSTED entry (a pending amendment doesn't change it until re-posted).
CREATE VIEW official_grades AS
  SELECT DISTINCT ON (enrollment_id) *
  FROM grade_entries
  WHERE status = 'posted'
  ORDER BY enrollment_id, created_at DESC, id DESC;

CREATE TABLE transcript_term_summaries (
  student_id         uuid NOT NULL REFERENCES students(id),
  term_id            uuid NOT NULL REFERENCES terms(id),
  credits_attempted  numeric(5,2),
  credits_earned     numeric(5,2),
  term_gpa           numeric(3,2),
  cumulative_gpa     numeric(3,2),
  computed_at        timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (student_id, term_id)                    -- derived projection; rebuildable
);

-- ───────── Finance (ledger) ─────────
CREATE TABLE accounts (
  id          uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  student_id  uuid NOT NULL UNIQUE REFERENCES students(id),
  currency    char(3) NOT NULL
);

CREATE TABLE ledger_entries (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  account_id      uuid NOT NULL REFERENCES accounts(id),
  term_id         uuid REFERENCES terms(id),
  kind            ledger_kind NOT NULL,
  amount_minor    bigint NOT NULL,                     -- signed: charges +, payments -
  currency        char(3) NOT NULL,
  reference_type  varchar(32),
  reference_id    uuid,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ledger_entries_account_idx ON ledger_entries (account_id, created_at);

CREATE TABLE payments (
  id               uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  account_id       uuid NOT NULL REFERENCES accounts(id),
  gateway          varchar(32) NOT NULL,
  gateway_ref      varchar(200) NOT NULL,
  amount_minor     bigint NOT NULL CHECK (amount_minor > 0),
  currency         char(3) NOT NULL,
  status           payment_status NOT NULL DEFAULT 'pending',
  idempotency_key  varchar(200) NOT NULL UNIQUE,
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (gateway, gateway_ref)
);

CREATE TABLE holds (
  id           uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  student_id   uuid NOT NULL REFERENCES students(id),
  type         hold_type NOT NULL,
  blocks       text[] NOT NULL DEFAULT '{}',           -- registration | transcripts | graduation
  placed_by    uuid REFERENCES users(id),
  placed_at    timestamptz NOT NULL DEFAULT now(),
  released_at  timestamptz
);
CREATE INDEX holds_student_active_idx ON holds (student_id) WHERE released_at IS NULL;

-- ───────── Cross-cutting ─────────
CREATE TABLE audit_log (
  id             uuid NOT NULL DEFAULT uuid_generate_v7(),
  campus_id      uuid NOT NULL,
  actor_user_id  uuid,
  action         varchar(64) NOT NULL,
  resource_type  varchar(48) NOT NULL,
  resource_id    uuid,
  student_id     uuid,                                 -- set when an education record is accessed/changed (FERPA log)
  before         jsonb,
  after          jsonb,
  request_id     varchar(64),
  created_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);
-- Default partition so inserts never fail; in production manage monthly partitions with pg_partman.
CREATE TABLE audit_log_default PARTITION OF audit_log DEFAULT;
CREATE INDEX audit_log_student_idx ON audit_log (student_id, created_at DESC);
CREATE INDEX audit_log_actor_idx   ON audit_log (actor_user_id, created_at DESC);

CREATE TABLE outbox_events (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
  aggregate_type  varchar(48) NOT NULL,
  aggregate_id    uuid NOT NULL,
  event_type      varchar(64) NOT NULL,
  payload         jsonb NOT NULL DEFAULT '{}',
  created_at      timestamptz NOT NULL DEFAULT now(),
  published_at    timestamptz
);
CREATE INDEX outbox_unpublished_idx ON outbox_events (id) WHERE published_at IS NULL;

-- ───────── Immutability (defense in depth; the app role also lacks UPDATE/DELETE) ─────────
CREATE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN RAISE EXCEPTION '% is append-only', TG_TABLE_NAME; END $$ LANGUAGE plpgsql;

CREATE TRIGGER grade_entries_immutable  BEFORE UPDATE OR DELETE ON grade_entries  FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER ledger_entries_immutable BEFORE UPDATE OR DELETE ON ledger_entries FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER audit_log_immutable      BEFORE UPDATE OR DELETE ON audit_log      FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- ───────── Row-Level Security (multi-campus isolation) ─────────
-- The API sets app.campus_id per transaction. app.elevated='on' is for audited cross-campus work
-- (identity lookup, outbox relay, IT super-admin).
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['users','students','departments','terms','sections','enrollments','audit_log'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format($p$
      CREATE POLICY campus_isolation ON %I
        USING (campus_id = nullif(current_setting('app.campus_id', true), '')::uuid
               OR current_setting('app.elevated', true) = 'on')
        WITH CHECK (campus_id = nullif(current_setting('app.campus_id', true), '')::uuid
               OR current_setting('app.elevated', true) = 'on')
    $p$, t);
  END LOOP;
END $$;

-- ───────── Application role (NOT the table owner, so RLS is enforced) ─────────
DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'portal_app') THEN
    CREATE ROLE portal_app LOGIN PASSWORD 'portal_app_dev';   -- change in any real environment
  END IF;
END $$;

GRANT USAGE ON SCHEMA public TO portal_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO portal_app;
REVOKE UPDATE, DELETE ON grade_entries, ledger_entries, audit_log, audit_log_default FROM portal_app;
