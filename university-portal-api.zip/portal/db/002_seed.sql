-- Dev seed. Runs as superuser (bypasses RLS). Fixed UUIDs so the curl examples in the README work.

INSERT INTO campuses (id, code, name, timezone) VALUES
  ('c0000000-0000-7000-8000-000000000001', 'MAIN', 'Main Campus', 'Africa/Lagos');

INSERT INTO users (id, campus_id, idp_subject, email) VALUES
  ('b0000000-0000-7000-8000-000000000001', 'c0000000-0000-7000-8000-000000000001', 'student-1',   'student1@uni.test'),
  ('b0000000-0000-7000-8000-000000000002', 'c0000000-0000-7000-8000-000000000001', 'student-2',   'student2@uni.test'),
  ('b0000000-0000-7000-8000-000000000003', 'c0000000-0000-7000-8000-000000000001', 'student-3',   'student3@uni.test'),
  ('b0000000-0000-7000-8000-000000000004', 'c0000000-0000-7000-8000-000000000001', 'faculty-1',   'faculty1@uni.test'),
  ('b0000000-0000-7000-8000-000000000005', 'c0000000-0000-7000-8000-000000000001', 'registrar-1', 'registrar1@uni.test'),
  ('b0000000-0000-7000-8000-000000000006', 'c0000000-0000-7000-8000-000000000001', 'depthead-1',  'depthead1@uni.test');

INSERT INTO departments (id, campus_id, code, name) VALUES
  ('d0000000-0000-7000-8000-000000000001', 'c0000000-0000-7000-8000-000000000001', 'CSC', 'Computer Science');

INSERT INTO employees (id, user_id, employee_number, department_id, title) VALUES
  ('b2000000-0000-7000-8000-000000000001', 'b0000000-0000-7000-8000-000000000004', 'E-001', 'd0000000-0000-7000-8000-000000000001', 'Lecturer'),
  ('b2000000-0000-7000-8000-000000000002', 'b0000000-0000-7000-8000-000000000006', 'E-002', 'd0000000-0000-7000-8000-000000000001', 'Head of Department');

UPDATE departments SET head_employee_id = 'b2000000-0000-7000-8000-000000000002'
 WHERE id = 'd0000000-0000-7000-8000-000000000001';

INSERT INTO programs (id, department_id, code, name, degree_level, total_credits_required) VALUES
  ('b4000000-0000-7000-8000-000000000001', 'd0000000-0000-7000-8000-000000000001', 'BSC-CSC', 'BSc Computer Science', 'bachelor', 120);

INSERT INTO terms (id, campus_id, code, starts_on, ends_on, registration_opens_at, add_deadline, drop_deadline, withdraw_deadline, status) VALUES
  ('f0000000-0000-7000-8000-000000000001', 'c0000000-0000-7000-8000-000000000001', '2026FA',
   current_date + 30, current_date + 150,
   now() - interval '1 day', now() + interval '30 days', now() + interval '14 days', now() + interval '45 days',
   'registration');

INSERT INTO students (id, campus_id, user_id, student_number, program_id, admit_term_id) VALUES
  ('b1000000-0000-7000-8000-000000000001', 'c0000000-0000-7000-8000-000000000001', 'b0000000-0000-7000-8000-000000000001', 'S-0001', 'b4000000-0000-7000-8000-000000000001', 'f0000000-0000-7000-8000-000000000001'),
  ('b1000000-0000-7000-8000-000000000002', 'c0000000-0000-7000-8000-000000000001', 'b0000000-0000-7000-8000-000000000002', 'S-0002', 'b4000000-0000-7000-8000-000000000001', 'f0000000-0000-7000-8000-000000000001'),
  ('b1000000-0000-7000-8000-000000000003', 'c0000000-0000-7000-8000-000000000001', 'b0000000-0000-7000-8000-000000000003', 'S-0003', 'b4000000-0000-7000-8000-000000000001', 'f0000000-0000-7000-8000-000000000001');

INSERT INTO courses (id, department_id, code, title, credits) VALUES
  ('e0000000-0000-7000-8000-000000000001', 'd0000000-0000-7000-8000-000000000001', 'CSC-101', 'Intro to Programming', 3),
  ('e0000000-0000-7000-8000-000000000002', 'd0000000-0000-7000-8000-000000000001', 'CSC-201', 'Data Structures', 3);

INSERT INTO course_requisites (course_id, required_course_id, kind, min_grade) VALUES
  ('e0000000-0000-7000-8000-000000000002', 'e0000000-0000-7000-8000-000000000001', 'prerequisite', 'C');

-- Section 1: capacity 2, waitlist 1 -> the 4th student is rejected, the 3rd is waitlisted.
INSERT INTO sections (id, campus_id, course_id, term_id, section_code, capacity, waitlist_capacity, status) VALUES
  ('a0000000-0000-7000-8000-000000000001', 'c0000000-0000-7000-8000-000000000001', 'e0000000-0000-7000-8000-000000000001', 'f0000000-0000-7000-8000-000000000001', 'A', 2, 1, 'open'),
  ('a0000000-0000-7000-8000-000000000002', 'c0000000-0000-7000-8000-000000000001', 'e0000000-0000-7000-8000-000000000002', 'f0000000-0000-7000-8000-000000000001', 'A', 30, 5, 'open');

INSERT INTO section_instructors (section_id, employee_id) VALUES
  ('a0000000-0000-7000-8000-000000000001', 'b2000000-0000-7000-8000-000000000001'),
  ('a0000000-0000-7000-8000-000000000002', 'b2000000-0000-7000-8000-000000000001');

INSERT INTO section_meetings (section_id, day_of_week, starts_at, ends_at, room) VALUES
  ('a0000000-0000-7000-8000-000000000001', 1, '09:00', '10:00', 'LT-1'),
  ('a0000000-0000-7000-8000-000000000002', 1, '09:30', '10:30', 'LT-2');   -- overlaps section 1 on purpose

INSERT INTO roles (id, key, scope_type) VALUES
  ('b3000000-0000-7000-8000-000000000001', 'student',       'campus'),
  ('b3000000-0000-7000-8000-000000000002', 'faculty',       'campus'),
  ('b3000000-0000-7000-8000-000000000003', 'dept_head',     'department'),
  ('b3000000-0000-7000-8000-000000000004', 'registrar',     'campus'),
  ('b3000000-0000-7000-8000-000000000005', 'billing_admin', 'campus'),
  ('b3000000-0000-7000-8000-000000000006', 'it_admin',      'global');

INSERT INTO role_assignments (user_id, role_id, scope_id) VALUES
  ('b0000000-0000-7000-8000-000000000001', 'b3000000-0000-7000-8000-000000000001', 'c0000000-0000-7000-8000-000000000001'),
  ('b0000000-0000-7000-8000-000000000002', 'b3000000-0000-7000-8000-000000000001', 'c0000000-0000-7000-8000-000000000001'),
  ('b0000000-0000-7000-8000-000000000003', 'b3000000-0000-7000-8000-000000000001', 'c0000000-0000-7000-8000-000000000001'),
  ('b0000000-0000-7000-8000-000000000004', 'b3000000-0000-7000-8000-000000000002', 'c0000000-0000-7000-8000-000000000001'),
  ('b0000000-0000-7000-8000-000000000005', 'b3000000-0000-7000-8000-000000000004', 'c0000000-0000-7000-8000-000000000001'),
  ('b0000000-0000-7000-8000-000000000006', 'b3000000-0000-7000-8000-000000000003', 'd0000000-0000-7000-8000-000000000001');

INSERT INTO grade_scales (symbol, points, counts_in_gpa) VALUES
  ('A', 4.00, true), ('A-', 3.70, true), ('B+', 3.30, true), ('B', 3.00, true), ('B-', 2.70, true),
  ('C+', 2.30, true), ('C', 2.00, true), ('C-', 1.70, true), ('D', 1.00, true), ('F', 0.00, true);
