// k6 run -e BASE=http://localhost:3000 -e SECTION=a0000000-0000-7000-8000-000000000002 load/register.k6.js
// Seed note: only 3 seeded students exist. For a real 10k-user run, bulk-insert users/students first
// and map __VU to an idp_subject (e.g. student-<n>).
import http from 'k6/http';
import { check } from 'k6';

export const options = {
  scenarios: {
    spike: { executor: 'ramping-arrival-rate', startRate: 50, timeUnit: '1s', preAllocatedVUs: 500, maxVUs: 3000,
             stages: [{ target: 2000, duration: '10s' }, { target: 2000, duration: '30s' }] },
  },
  thresholds: { http_req_duration: ['p(95)<800'], checks: ['rate>0.99'] },
};

export default function () {
  const n = (__VU % 3) + 1; // seed has student-1..3
  const res = http.post(`${__ENV.BASE}/v1/registrations`, JSON.stringify({ sectionId: __ENV.SECTION }), {
    headers: { 'Content-Type': 'application/json', 'x-dev-sub': `student-${n}`, 'Idempotency-Key': `${__VU}-${__ITER}` },
  });
  // 201 enrolled/waitlisted, 409 = full/duplicate/etc. are all *correct* outcomes; 5xx is not.
  check(res, { 'no server error': (r) => r.status < 500 });
}
