import { Module } from '@nestjs/common';
import { CommonModule } from './common/common.module';
import { GradingModule } from './grading/grading.module';
import { OutboxModule } from './outbox/outbox.module';
import { RegistrationModule } from './registration/registration.module';

@Module({ imports: [CommonModule, RegistrationModule, GradingModule, OutboxModule] })
export class AppModule {}
