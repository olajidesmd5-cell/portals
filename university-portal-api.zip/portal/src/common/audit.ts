import { PoolClient } from 'pg';
import { Ctx } from './ctx';

export interface AuditEntry {
  action: string;
  resourceType: string;
  resourceId?: string | null;
  /** Set whenever an education record about a student is read or changed (FERPA disclosure log). */
  studentId?: string | null;
  before?: unknown;
  after?: unknown;
}

/** Writes inside the caller's transaction so the audit row commits or rolls back with the change. */
export async function audit(c: PoolClient, ctx: Ctx, e: AuditEntry): Promise<void> {
  await c.query(
    `INSERT INTO audit_log (campus_id, actor_user_id, action, resource_type, resource_id, student_id, before, after, request_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
    [
      ctx.campusId, ctx.userId, e.action, e.resourceType, e.resourceId ?? null, e.studentId ?? null,
      e.before === undefined ? null : JSON.stringify(e.before),
      e.after === undefined ? null : JSON.stringify(e.after),
      ctx.requestId,
    ],
  );
}

/** Transactional outbox: the event commits atomically with the state change. */
export async function emit(
  c: PoolClient,
  aggregateType: string,
  aggregateId: string,
  eventType: string,
  payload: Record<string, unknown> = {},
): Promise<void> {
  await c.query(
    `INSERT INTO outbox_events (aggregate_type, aggregate_id, event_type, payload) VALUES ($1,$2,$3,$4)`,
    [aggregateType, aggregateId, eventType, JSON.stringify(payload)],
  );
}
