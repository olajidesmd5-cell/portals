import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { randomUUID } from 'crypto';
import { AuthService } from './auth.service';
import { PERMISSIONS_KEY, PUBLIC_KEY } from './decorators';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly auth: AuthService, private readonly reflector: Reflector) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const targets = [context.getHandler(), context.getClass()];
    if (this.reflector.getAllAndOverride<boolean>(PUBLIC_KEY, targets)) return true;

    const req = context.switchToHttp().getRequest();
    const sub = await this.auth.authenticate(req);
    const requestId = (req.headers['x-request-id'] as string) || randomUUID();
    req.ctx = await this.auth.buildCtx(sub, requestId);

    const required = this.reflector.getAllAndOverride<string[]>(PERMISSIONS_KEY, targets);
    if (required?.length && !required.some((p) => req.ctx.has(p))) throw new ForbiddenException();
    return true;
  }
}
