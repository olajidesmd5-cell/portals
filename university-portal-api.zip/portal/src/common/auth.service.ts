import { Injectable, UnauthorizedException } from '@nestjs/common';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { DbService } from './db.service';
import { RedisService } from './redis.service';
import { Ctx } from './ctx';
import { CtxBase, makeCtx } from './policy';

const AUTHZ_TTL_SECONDS = 300;

@Injectable()
export class AuthService {
  private jwks = process.env.OIDC_JWKS_URL ? createRemoteJWKSet(new URL(process.env.OIDC_JWKS_URL)) : null;

  constructor(private readonly db: DbService, private readonly redis: RedisService) {}

  /** Returns the IdP subject ("sub") for the request, or throws 401. */
  async authenticate(req: { headers: Record<string, string | string[] | undefined> }): Promise<string> {
    // DEV ONLY shortcut for local testing with the seed data. Hard-disabled in production.
    if (process.env.NODE_ENV !== 'production' && process.env.DEV_AUTH === 'true') {
      const sub = req.headers['x-dev-sub'];
      if (typeof sub === 'string' && sub) return sub;
    }
    const header = req.headers['authorization'];
    const token = typeof header === 'string' && header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token || !this.jwks) throw new UnauthorizedException();
    try {
      const { payload } = await jwtVerify(token, this.jwks, {
        issuer: process.env.OIDC_ISSUER,
        audience: process.env.OIDC_AUDIENCE,
      });
      if (!payload.sub) throw new Error('missing sub');
      return payload.sub;
    } catch {
      throw new UnauthorizedException();
    }
  }

  async buildCtx(sub: string, requestId: string): Promise<Ctx> {
    const key = `authz:${sub}`;
    let base: CtxBase | null = null;
    try {
      const cached = await this.redis.client.get(key);
      if (cached) base = JSON.parse(cached) as CtxBase;
    } catch {
      /* Redis down: fall through to the database */
    }
    if (!base) {
      base = await this.loadFromDb(sub);
      this.redis.client.set(key, JSON.stringify(base), 'EX', AUTHZ_TTL_SECONDS).catch(() => undefined);
    }
    return makeCtx(base, requestId);
  }

  /** Call when role_assignments change so permissions take effect immediately, not after the TTL. */
  async invalidate(sub: string): Promise<void> {
    await this.redis.client.del(`authz:${sub}`).catch(() => undefined);
  }

  private loadFromDb(sub: string): Promise<CtxBase> {
    // Elevated: we don't know the campus until we've found the user.
    return this.db.tx({ elevated: true }, async (c) => {
      const u = await c.query(
        `SELECT u.id, u.campus_id, s.id AS student_id, e.id AS employee_id
           FROM users u
           LEFT JOIN students  s ON s.user_id = u.id
           LEFT JOIN employees e ON e.user_id = u.id
          WHERE u.idp_subject = $1 AND u.status = 'active' AND u.deleted_at IS NULL`,
        [sub],
      );
      if (!u.rowCount) throw new UnauthorizedException('Unknown or inactive user');
      const row = u.rows[0];
      const r = await c.query(
        `SELECT r.key, ra.scope_id
           FROM role_assignments ra JOIN roles r ON r.id = ra.role_id
          WHERE ra.user_id = $1 AND ra.valid_from <= now() AND (ra.valid_to IS NULL OR ra.valid_to > now())`,
        [row.id],
      );
      return {
        userId: row.id,
        campusId: row.campus_id,
        studentId: row.student_id,
        employeeId: row.employee_id,
        roles: r.rows.map((x) => ({ key: x.key, scopeId: x.scope_id })),
      };
    });
  }
}
