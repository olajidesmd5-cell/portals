import { Global, Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { AuthGuard } from './auth.guard';
import { AuthService } from './auth.service';
import { DbService } from './db.service';
import { HealthController } from './health.controller';
import { RedisService } from './redis.service';

@Global()
@Module({
  controllers: [HealthController],
  providers: [DbService, RedisService, AuthService, { provide: APP_GUARD, useClass: AuthGuard }],
  exports: [DbService, RedisService, AuthService],
})
export class CommonModule {}
