export interface RoleGrant {
  key: string;
  scopeId: string | null;
}

/** Per-request identity + authorization context, attached to the request by AuthGuard. */
export interface Ctx {
  userId: string;
  campusId: string;
  studentId: string | null;
  employeeId: string | null;
  roles: RoleGrant[];
  requestId: string;
  /** True if any of the user's roles grants this permission ('*' grants everything). */
  has(permission: string): boolean;
  /** True if the user holds the role, optionally scoped (e.g. dept_head of a specific department). */
  hasRole(key: string, scopeId?: string): boolean;
}
