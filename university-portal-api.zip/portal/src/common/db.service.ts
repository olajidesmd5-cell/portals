import { Injectable, OnModuleDestroy } from '@nestjs/common';
import { Pool, PoolClient } from 'pg';

export interface TxScope {
  campusId?: string;
  userId?: string;
  /** Bypasses campus RLS. Only for identity lookup, the outbox relay, and audited super-admin work. */
  elevated?: boolean;
}

@Injectable()
export class DbService implements OnModuleDestroy {
  readonly pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: Number(process.env.DB_POOL_MAX ?? 20),
    idleTimeoutMillis: 30_000,
    statement_timeout: 10_000, // never let a stuck query hold a registration connection
  });

  /**
   * Runs fn in a transaction with RLS session variables set (SET LOCAL semantics via set_config(..., true)),
   * so they are transaction-scoped and safe behind PgBouncer transaction pooling.
   */
  async tx<T>(scope: TxScope, fn: (c: PoolClient) => Promise<T>): Promise<T> {
    const c = await this.pool.connect();
    try {
      await c.query('BEGIN');
      await c.query(
        `SELECT set_config('app.campus_id', $1, true),
                set_config('app.user_id',   $2, true),
                set_config('app.elevated',  $3, true)`,
        [scope.campusId ?? '', scope.userId ?? '', scope.elevated ? 'on' : 'off'],
      );
      const result = await fn(c);
      await c.query('COMMIT');
      return result;
    } catch (err) {
      await c.query('ROLLBACK').catch(() => undefined);
      throw err;
    } finally {
      c.release();
    }
  }

  onModuleDestroy() {
    return this.pool.end();
  }
}
