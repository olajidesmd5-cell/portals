import { createParamDecorator, ExecutionContext, SetMetadata } from '@nestjs/common';
import { Ctx } from './ctx';

export const PERMISSIONS_KEY = 'permissions';
export const PUBLIC_KEY = 'isPublic';

/** Route requires ANY of the listed permissions. ABAC refinements happen in the service. */
export const RequirePermission = (...perms: string[]) => SetMetadata(PERMISSIONS_KEY, perms);
export const Public = () => SetMetadata(PUBLIC_KEY, true);

export const CurrentCtx = createParamDecorator((_: unknown, ec: ExecutionContext): Ctx => {
  return ec.switchToHttp().getRequest().ctx;
});
