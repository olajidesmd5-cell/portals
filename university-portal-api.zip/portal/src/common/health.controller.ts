import { Controller, Get } from '@nestjs/common';
import { Public } from './decorators';
import { DbService } from './db.service';

@Controller()
export class HealthController {
  constructor(private readonly db: DbService) {}

  @Public()
  @Get('health')
  async health() {
    await this.db.pool.query('SELECT 1');
    return { status: 'ok' };
  }
}
