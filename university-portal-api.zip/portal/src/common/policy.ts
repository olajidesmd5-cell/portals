import { Ctx, RoleGrant } from './ctx';

/**
 * Coarse permissions per role (RBAC half). Fine-grained checks (own record, own section,
 * own department) are ABAC and live next to the business rule in each service.
 * Replace this map with the finalized Section 3 matrix.
 */
export const ROLE_PERMISSIONS: Record<string, string[]> = {
  student:       ['registration.self', 'schedule.self'],
  faculty:       ['grades.submit', 'roster.read'],
  dept_head:     ['grades.approve', 'roster.read'],
  registrar:     ['registration.any', 'schedule.any', 'grades.post', 'grades.amend', 'roster.read'],
  billing_admin: ['holds.manage', 'ledger.read'],
  it_admin:      ['*'],
};

export interface CtxBase {
  userId: string;
  campusId: string;
  studentId: string | null;
  employeeId: string | null;
  roles: RoleGrant[];
}

export function makeCtx(base: CtxBase, requestId: string): Ctx {
  const perms = new Set<string>();
  for (const r of base.roles) for (const p of ROLE_PERMISSIONS[r.key] ?? []) perms.add(p);
  return {
    ...base,
    requestId,
    has: (p) => perms.has('*') || perms.has(p),
    hasRole: (key, scopeId) =>
      base.roles.some((r) => r.key === key && (scopeId === undefined || r.scopeId === scopeId)),
  };
}
