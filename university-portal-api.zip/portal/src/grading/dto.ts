import { Type } from 'class-transformer';
import { ArrayMaxSize, ArrayMinSize, IsArray, IsString, IsUUID, MaxLength, MinLength, ValidateNested } from 'class-validator';

export class GradeItemDto {
  @IsUUID()
  enrollmentId!: string;

  @IsString()
  @MaxLength(4)
  symbol!: string;
}

export class SubmitGradesDto {
  @IsArray()
  @ArrayMinSize(1)
  @ArrayMaxSize(500)
  @ValidateNested({ each: true })
  @Type(() => GradeItemDto)
  grades!: GradeItemDto[];
}

export class AmendGradeDto {
  @IsString()
  @MaxLength(4)
  symbol!: string;

  /** Mandatory justification: becomes part of the permanent audit trail. */
  @IsString()
  @MinLength(10)
  @MaxLength(1000)
  reason!: string;
}
