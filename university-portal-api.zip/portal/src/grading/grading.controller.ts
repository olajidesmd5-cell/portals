import { Body, Controller, Get, HttpCode, Param, ParseUUIDPipe, Post } from '@nestjs/common';
import { Ctx } from '../common/ctx';
import { CurrentCtx, RequirePermission } from '../common/decorators';
import { AmendGradeDto, SubmitGradesDto } from './dto';
import { GradingService } from './grading.service';

@Controller('v1')
export class GradingController {
  constructor(private readonly svc: GradingService) {}

  /** Faculty: submit (or correct, before approval) grades for their own section. */
  @Post('sections/:sectionId/grades')
  @HttpCode(200)
  @RequirePermission('grades.submit')
  submit(@CurrentCtx() ctx: Ctx, @Param('sectionId', ParseUUIDPipe) sectionId: string, @Body() dto: SubmitGradesDto) {
    return this.svc.submit(ctx, sectionId, dto);
  }

  /** Department head: approve every submitted grade in a section. */
  @Post('sections/:sectionId/grades/approve')
  @HttpCode(200)
  @RequirePermission('grades.approve')
  approve(@CurrentCtx() ctx: Ctx, @Param('sectionId', ParseUUIDPipe) sectionId: string) {
    return this.svc.approveSection(ctx, sectionId);
  }

  /** Registrar: publish approved grades to the official record. */
  @Post('sections/:sectionId/grades/post')
  @HttpCode(200)
  @RequirePermission('grades.post')
  post(@CurrentCtx() ctx: Ctx, @Param('sectionId', ParseUUIDPipe) sectionId: string) {
    return this.svc.postSection(ctx, sectionId);
  }

  @Get('sections/:sectionId/grades')
  @RequirePermission('roster.read')
  list(@CurrentCtx() ctx: Ctx, @Param('sectionId', ParseUUIDPipe) sectionId: string) {
    return this.svc.listSection(ctx, sectionId);
  }

  /** Registrar: request a change to an already-posted grade (reason required). */
  @Post('enrollments/:enrollmentId/grades/amend')
  @HttpCode(200)
  @RequirePermission('grades.amend')
  amend(@CurrentCtx() ctx: Ctx, @Param('enrollmentId', ParseUUIDPipe) enrollmentId: string, @Body() dto: AmendGradeDto) {
    return this.svc.amend(ctx, enrollmentId, dto);
  }
}
