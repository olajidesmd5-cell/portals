import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PoolClient } from 'pg';
import { audit, emit } from '../common/audit';
import { Ctx } from '../common/ctx';
import { DbService } from '../common/db.service';
import { AmendGradeDto, SubmitGradesDto } from './dto';

/**
 * Grade lifecycle (append-only chain; every transition inserts a NEW row superseding the previous head):
 *   submitted (faculty) → approved (department head) → posted (registrar)
 *   posted → submitted (registrar amendment, with reason) → approved → posted
 * A unique index on supersedes_id guarantees one successor per entry, so concurrent
 * approvals/posts/edits cannot both win.
 */
@Injectable()
export class GradingService {
  constructor(private readonly db: DbService) {}

  async submit(ctx: Ctx, sectionId: string, dto: SubmitGradesDto) {
    return this.conflictSafe(() =>
      this.db.tx(ctx, async (c) => {
        await this.loadSection(c, sectionId);
        if (!ctx.has('*')) await this.assertInstructor(c, ctx, sectionId);

        const ids = dto.grades.map((g) => g.enrollmentId);
        if (new Set(ids).size !== ids.length) throw new BadRequestException('Duplicate enrollmentId in request');

        const scale = await c.query(`SELECT symbol FROM grade_scales`);
        const valid = new Set(scale.rows.map((r) => r.symbol));
        const bad = dto.grades.filter((g) => !valid.has(g.symbol));
        if (bad.length) throw new BadRequestException({ code: 'INVALID_GRADE_SYMBOL', symbols: [...new Set(bad.map((b) => b.symbol))] });

        const { rows } = await c.query(
          `SELECT e.id AS enrollment_id, e.status AS enrollment_status, h.id AS head_id, h.status AS head_status
             FROM enrollments e
             LEFT JOIN grade_entries h ON h.enrollment_id = e.id
                  AND NOT EXISTS (SELECT 1 FROM grade_entries x WHERE x.supersedes_id = h.id)
            WHERE e.section_id = $1 AND e.id = ANY($2::uuid[])`,
          [sectionId, ids],
        );
        const byEnrollment = new Map(rows.map((r) => [r.enrollment_id, r]));
        const unknown = ids.filter((id) => !byEnrollment.has(id));
        if (unknown.length) throw new BadRequestException({ code: 'UNKNOWN_ENROLLMENTS', enrollmentIds: unknown });

        const locked = rows.filter((r) => r.enrollment_status !== 'enrolled' || (r.head_status && r.head_status !== 'submitted'));
        if (locked.length) {
          throw new ConflictException({
            code: 'GRADE_LOCKED',
            message: 'Approved/posted grades can only change through the amendment workflow',
            enrollmentIds: locked.map((r) => r.enrollment_id),
          });
        }

        await c.query(
          `INSERT INTO grade_entries (enrollment_id, symbol, points_snapshot, status, supersedes_id, submitted_by)
           SELECT x.enrollment_id, x.symbol, gs.points, 'submitted', x.head_id, $4
             FROM unnest($1::uuid[], $2::text[], $3::uuid[]) AS x(enrollment_id, symbol, head_id)
             JOIN grade_scales gs ON gs.symbol = x.symbol`,
          [ids, dto.grades.map((g) => g.symbol), ids.map((id) => byEnrollment.get(id).head_id ?? null), ctx.userId],
        );

        await emit(c, 'section', sectionId, 'GradesSubmitted', { sectionId, count: ids.length });
        await audit(c, ctx, { action: 'grades.submit', resourceType: 'section', resourceId: sectionId, after: { count: ids.length } });
        return { submitted: ids.length };
      }),
    );
  }

  async approveSection(ctx: Ctx, sectionId: string) {
    return this.conflictSafe(() =>
      this.db.tx(ctx, async (c) => {
        const sec = await this.loadSection(c, sectionId);
        if (!ctx.has('*') && !ctx.hasRole('dept_head', sec.department_id)) {
          throw new ForbiddenException('Only the owning department head can approve');
        }
        const { rows } = await c.query(
          `INSERT INTO grade_entries (enrollment_id, symbol, points_snapshot, status, supersedes_id, submitted_by, approved_by)
           SELECT g.enrollment_id, g.symbol, g.points_snapshot, 'approved', g.id, g.submitted_by, $2
             FROM grade_entries g JOIN enrollments e ON e.id = g.enrollment_id
            WHERE e.section_id = $1 AND g.status = 'submitted'
              AND NOT EXISTS (SELECT 1 FROM grade_entries x WHERE x.supersedes_id = g.id)
           RETURNING enrollment_id`,
          [sectionId, ctx.userId],
        );
        if (rows.length) {
          await emit(c, 'section', sectionId, 'GradesApproved', { sectionId, count: rows.length });
          await audit(c, ctx, { action: 'grades.approve', resourceType: 'section', resourceId: sectionId, after: { count: rows.length } });
        }
        return { approved: rows.length };
      }),
    );
  }

  async postSection(ctx: Ctx, sectionId: string) {
    return this.conflictSafe(() =>
      this.db.tx(ctx, async (c) => {
        await this.loadSection(c, sectionId);
        const { rows } = await c.query(
          `INSERT INTO grade_entries (enrollment_id, symbol, points_snapshot, status, supersedes_id, submitted_by, approved_by)
           SELECT g.enrollment_id, g.symbol, g.points_snapshot, 'posted', g.id, g.submitted_by, g.approved_by
             FROM grade_entries g JOIN enrollments e ON e.id = g.enrollment_id
            WHERE e.section_id = $1 AND g.status = 'approved'
              AND NOT EXISTS (SELECT 1 FROM grade_entries x WHERE x.supersedes_id = g.id)
           RETURNING enrollment_id, symbol`,
          [sectionId],
        );
        if (rows.length) {
          const enrollmentIds = rows.map((r) => r.enrollment_id);
          await c.query(
            `UPDATE enrollments SET status = 'completed', version = version + 1
              WHERE id = ANY($1::uuid[]) AND status = 'enrolled'`,
            [enrollmentIds],
          );
          // One event per enrollment: downstream recomputes the GPA projection and notifies the student.
          await c.query(
            `INSERT INTO outbox_events (aggregate_type, aggregate_id, event_type, payload)
             SELECT 'enrollment', x, 'GradePosted', jsonb_build_object('enrollmentId', x, 'sectionId', $2::text)
               FROM unnest($1::uuid[]) AS x`,
            [enrollmentIds, sectionId],
          );
          await audit(c, ctx, { action: 'grades.post', resourceType: 'section', resourceId: sectionId, after: { count: rows.length } });
        }
        return { posted: rows.length };
      }),
    );
  }

  async amend(ctx: Ctx, enrollmentId: string, dto: AmendGradeDto) {
    return this.conflictSafe(() =>
      this.db.tx(ctx, async (c) => {
        const scale = await c.query(`SELECT points FROM grade_scales WHERE symbol = $1`, [dto.symbol]);
        if (!scale.rowCount) throw new BadRequestException({ code: 'INVALID_GRADE_SYMBOL', symbols: [dto.symbol] });

        const { rows: [head] } = await c.query(
          `SELECT h.id, h.status, h.symbol, e.student_id
             FROM enrollments e
             JOIN grade_entries h ON h.enrollment_id = e.id
                  AND NOT EXISTS (SELECT 1 FROM grade_entries x WHERE x.supersedes_id = h.id)
            WHERE e.id = $1`,
          [enrollmentId],
        );
        if (!head) throw new NotFoundException('No grade found for enrollment');
        if (head.status !== 'posted') {
          throw new ConflictException({ code: 'NOT_POSTED', message: `Current grade is "${head.status}"; only posted grades are amended` });
        }

        await c.query(
          `INSERT INTO grade_entries (enrollment_id, symbol, points_snapshot, status, supersedes_id, submitted_by, reason)
           VALUES ($1, $2, $3, 'submitted', $4, $5, $6)`,
          [enrollmentId, dto.symbol, scale.rows[0].points, head.id, ctx.userId, dto.reason],
        );
        await emit(c, 'enrollment', enrollmentId, 'GradeAmendmentRequested', { enrollmentId });
        await audit(c, ctx, {
          action: 'grades.amend', resourceType: 'enrollment', resourceId: enrollmentId, studentId: head.student_id,
          before: { symbol: head.symbol }, after: { symbol: dto.symbol, reason: dto.reason },
        });
        return { enrollmentId, status: 'submitted', note: 'Amendment must be approved and posted before it takes effect' };
      }),
    );
  }

  async listSection(ctx: Ctx, sectionId: string) {
    return this.db.tx(ctx, async (c) => {
      const sec = await this.loadSection(c, sectionId);
      const privileged = ctx.has('*') || ctx.has('grades.post') || ctx.hasRole('dept_head', sec.department_id);
      if (!privileged) await this.assertInstructor(c, ctx, sectionId);

      const { rows } = await c.query(
        `SELECT e.id AS enrollment_id, st.student_number, e.status AS enrollment_status,
                h.symbol, h.status AS grade_status
           FROM enrollments e
           JOIN students st ON st.id = e.student_id
           LEFT JOIN grade_entries h ON h.enrollment_id = e.id
                AND NOT EXISTS (SELECT 1 FROM grade_entries x WHERE x.supersedes_id = h.id)
          WHERE e.section_id = $1 AND e.status IN ('enrolled','completed')
          ORDER BY st.student_number`,
        [sectionId],
      );
      await audit(c, ctx, { action: 'grades.list', resourceType: 'section', resourceId: sectionId });
      return rows;
    });
  }

  // ───────────────────────── helpers ─────────────────────────

  private async loadSection(c: PoolClient, sectionId: string): Promise<{ department_id: string }> {
    const { rows } = await c.query(
      `SELECT co.department_id FROM sections s JOIN courses co ON co.id = s.course_id WHERE s.id = $1`,
      [sectionId],
    );
    if (!rows.length) throw new NotFoundException('Section not found');
    return rows[0];
  }

  /** ABAC: faculty may only touch sections they teach. */
  private async assertInstructor(c: PoolClient, ctx: Ctx, sectionId: string) {
    if (!ctx.employeeId) throw new ForbiddenException();
    const r = await c.query(
      `SELECT 1 FROM section_instructors WHERE section_id = $1 AND employee_id = $2`,
      [sectionId, ctx.employeeId],
    );
    if (!r.rowCount) throw new ForbiddenException('You are not an instructor of this section');
  }

  /** The unique successor/root indexes turn a lost race into a clean 409 instead of a 500. */
  private async conflictSafe<T>(fn: () => Promise<T>): Promise<T> {
    try {
      return await fn();
    } catch (err: any) {
      if (err?.code === '23505' && String(err.constraint).startsWith('grade_entries_')) {
        throw new ConflictException({ code: 'CONCURRENT_UPDATE', message: 'Grades changed concurrently; reload and retry' });
      }
      throw err;
    }
  }
}
