import { Logger } from '@nestjs/common';
import { SQSClient, SendMessageBatchCommand } from '@aws-sdk/client-sqs';

export type OutboxRow = {
  id: string;
  aggregate_type: string;
  aggregate_id: string;
  event_type: string;
  payload: Record<string, unknown>;
};

export abstract class EventPublisher {
  /** Must throw if ANY event failed to publish; the relay then retries the whole batch (at-least-once). */
  abstract publishBatch(events: OutboxRow[]): Promise<void>;
}

/** Local/dev: just log. */
export class LogPublisher extends EventPublisher {
  private readonly log = new Logger('Outbox');
  async publishBatch(events: OutboxRow[]) {
    for (const e of events) this.log.log(`${e.event_type} ${e.aggregate_type}/${e.aggregate_id} ${JSON.stringify(e.payload)}`);
  }
}

/**
 * SQS standard queue. Delivery is at-least-once, so CONSUMERS MUST DEDUPE on the eventId attribute.
 * (For strict per-aggregate ordering use a FIFO queue with MessageGroupId = aggregate_id.)
 */
export class SqsPublisher extends EventPublisher {
  private readonly client = new SQSClient({ region: process.env.AWS_REGION });
  constructor(private readonly queueUrl: string) {
    super();
  }

  async publishBatch(events: OutboxRow[]) {
    for (let i = 0; i < events.length; i += 10) {
      const chunk = events.slice(i, i + 10);
      const res = await this.client.send(
        new SendMessageBatchCommand({
          QueueUrl: this.queueUrl,
          Entries: chunk.map((e) => ({
            Id: e.id,
            MessageBody: JSON.stringify({ eventId: e.id, type: e.event_type, aggregateId: e.aggregate_id, payload: e.payload }),
            MessageAttributes: {
              eventId: { DataType: 'String', StringValue: e.id },
              eventType: { DataType: 'String', StringValue: e.event_type },
            },
          })),
        }),
      );
      if (res.Failed?.length) throw new Error(`SQS rejected ${res.Failed.length} message(s)`);
    }
  }
}
