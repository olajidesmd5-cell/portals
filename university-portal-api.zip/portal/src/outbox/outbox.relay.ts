import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { DbService } from '../common/db.service';
import { EventPublisher, LogPublisher, OutboxRow, SqsPublisher } from './event-publisher';

const BATCH = 100;

/**
 * Polls the transactional outbox and publishes events. Safe to run on every API replica:
 * FOR UPDATE SKIP LOCKED means replicas take disjoint batches. At-least-once delivery.
 */
@Injectable()
export class OutboxRelay implements OnModuleInit, OnModuleDestroy {
  private readonly log = new Logger(OutboxRelay.name);
  private readonly publisher: EventPublisher = process.env.SQS_QUEUE_URL
    ? new SqsPublisher(process.env.SQS_QUEUE_URL)
    : new LogPublisher();
  private timer?: NodeJS.Timeout;
  private busy = false;

  constructor(private readonly db: DbService) {}

  onModuleInit() {
    if (process.env.OUTBOX_RELAY === 'off') return;
    this.timer = setInterval(() => void this.tick(), 500);
  }

  onModuleDestroy() {
    if (this.timer) clearInterval(this.timer);
  }

  private async tick() {
    if (this.busy) return;
    this.busy = true;
    try {
      let n: number;
      do {
        n = await this.drain();
      } while (n === BATCH);
    } catch (err) {
      this.log.error(`Relay tick failed (will retry): ${(err as Error).message}`);
    } finally {
      this.busy = false;
    }
  }

  private drain(): Promise<number> {
    return this.db.tx({ elevated: true }, async (c) => {
      const { rows } = await c.query<OutboxRow>(
        `SELECT id, aggregate_type, aggregate_id, event_type, payload
           FROM outbox_events WHERE published_at IS NULL
          ORDER BY id LIMIT ${BATCH} FOR UPDATE SKIP LOCKED`,
      );
      if (!rows.length) return 0;
      await this.publisher.publishBatch(rows); // throws → tx rolls back → rows stay unpublished
      await c.query(`UPDATE outbox_events SET published_at = now() WHERE id = ANY($1::uuid[])`, [rows.map((r) => r.id)]);
      return rows.length;
    });
  }
}
