import { IsOptional, IsUUID } from 'class-validator';

export class EnrollDto {
  @IsUUID()
  sectionId!: string;

  /** Omit to enroll yourself. Staff with registration.any may act on behalf of a student. */
  @IsOptional()
  @IsUUID()
  studentId?: string;
}

export class ScheduleQuery {
  @IsUUID()
  termId!: string;
}
