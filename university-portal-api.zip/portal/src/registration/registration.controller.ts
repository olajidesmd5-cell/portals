import { Body, Controller, Delete, Get, Headers, HttpCode, Param, ParseUUIDPipe, Post, Query } from '@nestjs/common';
import { Ctx } from '../common/ctx';
import { CurrentCtx, RequirePermission } from '../common/decorators';
import { EnrollDto, ScheduleQuery } from './dto';
import { RegistrationService } from './registration.service';

@Controller('v1')
export class RegistrationController {
  constructor(private readonly svc: RegistrationService) {}

  /** Idempotent. Returns 201 with status "enrolled" or "waitlisted"; 409 with a machine-readable code otherwise. */
  @Post('registrations')
  @RequirePermission('registration.self', 'registration.any')
  enroll(
    @CurrentCtx() ctx: Ctx,
    @Body() dto: EnrollDto,
    @Headers('idempotency-key') idempotencyKey?: string,
  ) {
    return this.svc.enroll(ctx, dto, idempotencyKey);
  }

  @Delete('registrations/:id')
  @HttpCode(200)
  @RequirePermission('registration.self', 'registration.any')
  drop(@CurrentCtx() ctx: Ctx, @Param('id', ParseUUIDPipe) id: string) {
    return this.svc.drop(ctx, id);
  }

  /** `studentId` may be the literal "me". */
  @Get('students/:studentId/schedule')
  @RequirePermission('schedule.self', 'schedule.any')
  schedule(@CurrentCtx() ctx: Ctx, @Param('studentId') studentId: string, @Query() q: ScheduleQuery) {
    return this.svc.schedule(ctx, studentId, q.termId);
  }

  @Get('sections/:id/availability')
  availability(@CurrentCtx() ctx: Ctx, @Param('id', ParseUUIDPipe) id: string) {
    return this.svc.availability(ctx, id);
  }
}
