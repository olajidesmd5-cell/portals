import { Module } from '@nestjs/common';
import { RegistrationController } from './registration.controller';
import { RegistrationService } from './registration.service';
import { SeatGate } from './seat-gate';

@Module({
  controllers: [RegistrationController],
  providers: [RegistrationService, SeatGate],
})
export class RegistrationModule {}
