import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PoolClient } from 'pg';
import { audit, emit } from '../common/audit';
import { Ctx } from '../common/ctx';
import { DbService } from '../common/db.service';
import { EnrollDto } from './dto';
import { SeatGate } from './seat-gate';

export interface EnrollResult {
  enrollmentId: string;
  status: 'enrolled' | 'waitlisted';
  waitlistPosition: number | null;
  replayed?: boolean;
}

@Injectable()
export class RegistrationService {
  constructor(private readonly db: DbService, private readonly gate: SeatGate) {}

  // ───────────────────────── enroll ─────────────────────────

  async enroll(ctx: Ctx, dto: EnrollDto, rawIdempotencyKey: string | undefined): Promise<EnrollResult> {
    if (!rawIdempotencyKey || rawIdempotencyKey.length > 120) {
      throw new BadRequestException('Idempotency-Key header is required (max 120 chars)');
    }
    const studentId = this.resolveStudent(ctx, dto.studentId);
    const idemKey = `${studentId}:${rawIdempotencyKey}`;

    // 1. Replays return the original outcome, even if the section has since filled up.
    const prior = await this.db.tx(ctx, (c) => this.findByIdemKey(c, idemKey));
    if (prior) return { ...prior, replayed: true };

    // 2. Shed load in Redis before touching Postgres.
    const admitted = await this.gate.admit(dto.sectionId, () => this.loadRemaining(ctx, dto.sectionId));
    if (!admitted) throw new ConflictException({ code: 'SECTION_FULL', message: 'Section and waitlist are full' });

    try {
      return await this.db.tx(ctx, (c) => this.enrollTx(c, ctx, dto.sectionId, studentId, idemKey));
    } catch (err: any) {
      await this.gate.release(dto.sectionId); // no seat/waitlist spot was consumed
      if (err?.code === '23505') {
        if (err.constraint === 'enrollments_active_uq') {
          throw new ConflictException({ code: 'ALREADY_REGISTERED', message: 'Already enrolled or waitlisted' });
        }
        if (err.constraint === 'enrollments_idem_uq') {
          // A concurrent request with the same key won the race: return its result.
          const winner = await this.db.tx(ctx, (c) => this.findByIdemKey(c, idemKey));
          if (winner) return { ...winner, replayed: true };
        }
      }
      throw err;
    }
  }

  private async enrollTx(
    c: PoolClient, ctx: Ctx, sectionId: string, studentId: string, idemKey: string,
  ): Promise<EnrollResult> {
    // Context + all deadline math done by the database clock.
    const { rows: [sec] } = await c.query(
      `SELECT s.id, s.status, s.term_id, s.campus_id, s.course_id, co.credits,
              t.status AS term_status,
              (t.registration_opens_at IS NULL OR now() >= t.registration_opens_at) AS reg_open,
              (t.add_deadline IS NULL OR now() <= t.add_deadline)                   AS before_add_deadline
         FROM sections s
         JOIN courses co ON co.id = s.course_id
         JOIN terms   t  ON t.id  = s.term_id
        WHERE s.id = $1`,
      [sectionId],
    );
    if (!sec) throw new NotFoundException('Section not found');
    if (sec.status !== 'open') throw new ConflictException({ code: 'SECTION_CLOSED' });
    if (!['registration', 'active'].includes(sec.term_status) || !sec.reg_open || !sec.before_add_deadline) {
      throw new ConflictException({ code: 'REGISTRATION_CLOSED' });
    }

    // Financial / academic holds that block registration.
    const hold = await c.query(
      `SELECT type FROM holds
        WHERE student_id = $1 AND released_at IS NULL AND 'registration' = ANY(blocks) LIMIT 1`,
      [studentId],
    );
    if (hold.rowCount) throw new ForbiddenException({ code: 'REGISTRATION_HOLD', holdType: hold.rows[0].type });

    // Prerequisites: each must have an official (posted) grade that meets min_grade (or any non-zero grade).
    const missing = await c.query(
      `SELECT cr.required_course_id
         FROM course_requisites cr
        WHERE cr.course_id = $1 AND cr.kind = 'prerequisite'
          AND NOT EXISTS (
            SELECT 1
              FROM enrollments e
              JOIN sections s2        ON s2.id = e.section_id
              JOIN official_grades g  ON g.enrollment_id = e.id
             WHERE e.student_id = $2 AND e.status = 'completed' AND s2.course_id = cr.required_course_id
               AND g.points_snapshot >= COALESCE((SELECT points FROM grade_scales WHERE symbol = cr.min_grade), 0.01)
          )`,
      [sec.course_id, studentId],
    );
    if (missing.rowCount) {
      throw new ConflictException({
        code: 'PREREQUISITES_NOT_MET',
        missingCourseIds: missing.rows.map((r) => r.required_course_id),
      });
    }

    // Time conflicts with sections the student is already enrolled in this term.
    const clash = await c.query(
      `SELECT 1
         FROM section_meetings mn
         JOIN section_meetings mo ON mo.day_of_week = mn.day_of_week
                                 AND mo.starts_at < mn.ends_at AND mn.starts_at < mo.ends_at
         JOIN enrollments e ON e.section_id = mo.section_id
                           AND e.student_id = $2 AND e.term_id = $3 AND e.status = 'enrolled'
        WHERE mn.section_id = $1 LIMIT 1`,
      [sectionId, studentId, sec.term_id],
    );
    if (clash.rowCount) throw new ConflictException({ code: 'SCHEDULE_CONFLICT' });

    // ── The race-free core: ONE guarded statement per resource. Row-level atomicity, no explicit locks. ──
    let status: 'enrolled' | 'waitlisted';
    let position: number | null = null;

    const seat = await c.query(
      `UPDATE sections SET enrolled_count = enrolled_count + 1
        WHERE id = $1 AND status = 'open' AND enrolled_count < capacity
        RETURNING enrolled_count`,
      [sectionId],
    );
    if (seat.rowCount === 1) {
      status = 'enrolled';
    } else {
      const wl = await c.query(
        `UPDATE sections SET waitlist_count = waitlist_count + 1, waitlist_seq = waitlist_seq + 1
          WHERE id = $1 AND waitlist_count < waitlist_capacity
          RETURNING waitlist_seq`,
        [sectionId],
      );
      if (wl.rowCount === 0) throw new ConflictException({ code: 'SECTION_FULL' });
      status = 'waitlisted';
      position = wl.rows[0].waitlist_seq; // atomically assigned ticket
    }

    const { rows: [enr] } = await c.query(
      `INSERT INTO enrollments (campus_id, student_id, section_id, term_id, status, credits_snapshot, idempotency_key, enrolled_at)
       VALUES ($1,$2,$3,$4,$5::enrollment_status,$6,$7, CASE WHEN $5::enrollment_status = 'enrolled' THEN now() END)
       RETURNING id`,
      [sec.campus_id, studentId, sectionId, sec.term_id, status, sec.credits, idemKey],
    );
    if (status === 'waitlisted') {
      await c.query(
        `INSERT INTO waitlist_entries (section_id, student_id, enrollment_id, position) VALUES ($1,$2,$3,$4)`,
        [sectionId, studentId, enr.id, position],
      );
    }

    await emit(c, 'enrollment', enr.id, status === 'enrolled' ? 'EnrollmentConfirmed' : 'WaitlistJoined', {
      enrollmentId: enr.id, studentId, sectionId, termId: sec.term_id, credits: Number(sec.credits), position,
    });
    await audit(c, ctx, {
      action: `registration.${status}`, resourceType: 'enrollment', resourceId: enr.id, studentId,
      after: { sectionId, status, position },
    });

    return { enrollmentId: enr.id, status, waitlistPosition: position };
  }

  // ───────────────────────── drop / withdraw ─────────────────────────

  async drop(ctx: Ctx, enrollmentId: string) {
    let sectionId = '';
    const result = await this.db.tx(ctx, async (c) => {
      const { rows: [e] } = await c.query(
        `SELECT e.id, e.student_id, e.section_id, e.status,
                (t.drop_deadline     IS NULL OR now() <= t.drop_deadline)     AS can_drop,
                (t.withdraw_deadline IS NULL OR now() <= t.withdraw_deadline) AS can_withdraw
           FROM enrollments e JOIN terms t ON t.id = e.term_id
          WHERE e.id = $1
          FOR UPDATE OF e`,
        [enrollmentId],
      );
      // 404 (not 403) for other people's records: don't confirm existence.
      if (!e || (e.student_id !== ctx.studentId && !ctx.has('registration.any'))) {
        throw new NotFoundException('Enrollment not found');
      }
      if (e.status !== 'enrolled' && e.status !== 'waitlisted') {
        throw new ConflictException({ code: 'NOT_ACTIVE', message: `Enrollment is ${e.status}` });
      }
      sectionId = e.section_id;

      let newStatus: 'dropped' | 'withdrawn' = 'dropped';
      if (e.status === 'enrolled' && !e.can_drop) {
        if (!e.can_withdraw) throw new ConflictException({ code: 'PAST_WITHDRAW_DEADLINE' });
        newStatus = 'withdrawn'; // appears as "W" on the transcript
      }

      await c.query(
        `UPDATE enrollments SET status = $2, dropped_at = now(), version = version + 1 WHERE id = $1`,
        [enrollmentId, newStatus],
      );

      let promotedEnrollmentId: string | null = null;
      if (e.status === 'waitlisted') {
        await c.query(`DELETE FROM waitlist_entries WHERE enrollment_id = $1`, [enrollmentId]);
        await c.query(`UPDATE sections SET waitlist_count = waitlist_count - 1 WHERE id = $1`, [sectionId]);
      } else {
        // Hand the seat to the next waiter. SKIP LOCKED: concurrent drops promote different people.
        const next = await c.query(
          `SELECT id, enrollment_id FROM waitlist_entries
            WHERE section_id = $1 ORDER BY position LIMIT 1 FOR UPDATE SKIP LOCKED`,
          [sectionId],
        );
        if (next.rowCount) {
          promotedEnrollmentId = next.rows[0].enrollment_id;
          await c.query(`DELETE FROM waitlist_entries WHERE id = $1`, [next.rows[0].id]);
          await c.query(
            `UPDATE enrollments SET status = 'enrolled', enrolled_at = now(), version = version + 1 WHERE id = $1`,
            [promotedEnrollmentId],
          );
          // seat transfers: enrolled_count unchanged, waitlist shrinks
          await c.query(`UPDATE sections SET waitlist_count = waitlist_count - 1 WHERE id = $1`, [sectionId]);
          await emit(c, 'enrollment', promotedEnrollmentId!, 'WaitlistPromoted', { enrollmentId: promotedEnrollmentId, sectionId });
        } else {
          await c.query(`UPDATE sections SET enrolled_count = enrolled_count - 1 WHERE id = $1`, [sectionId]);
        }
      }

      await emit(c, 'enrollment', enrollmentId, newStatus === 'dropped' ? 'EnrollmentDropped' : 'EnrollmentWithdrawn', {
        enrollmentId, studentId: e.student_id, sectionId,
      });
      await audit(c, ctx, {
        action: `registration.${newStatus}`, resourceType: 'enrollment', resourceId: enrollmentId,
        studentId: e.student_id, before: { status: e.status }, after: { status: newStatus },
      });
      return { enrollmentId, status: newStatus, promotedEnrollmentId };
    });
    await this.gate.invalidate(sectionId);
    return result;
  }

  // ───────────────────────── reads ─────────────────────────

  async schedule(ctx: Ctx, studentIdParam: string, termId: string) {
    const studentId = studentIdParam === 'me' ? ctx.studentId : studentIdParam;
    if (!studentId) throw new BadRequestException('Not a student account');
    const own = studentId === ctx.studentId;
    if (!(own && ctx.has('schedule.self')) && !ctx.has('schedule.any')) throw new ForbiddenException();

    return this.db.tx(ctx, async (c) => {
      const { rows } = await c.query(
        `SELECT e.id AS enrollment_id, e.status, e.credits_snapshot AS credits,
                co.code AS course_code, co.title, s.id AS section_id, s.section_code,
                COALESCE(json_agg(json_build_object(
                  'day', m.day_of_week, 'start', to_char(m.starts_at,'HH24:MI'),
                  'end', to_char(m.ends_at,'HH24:MI'), 'room', m.room))
                  FILTER (WHERE m.id IS NOT NULL), '[]') AS meetings
           FROM enrollments e
           JOIN sections s  ON s.id = e.section_id
           JOIN courses co  ON co.id = s.course_id
           LEFT JOIN section_meetings m ON m.section_id = s.id
          WHERE e.student_id = $1 AND e.term_id = $2 AND e.status IN ('enrolled','waitlisted')
          GROUP BY e.id, co.code, co.title, s.id
          ORDER BY co.code`,
        [studentId, termId],
      );
      if (!own) {
        await audit(c, ctx, { action: 'schedule.read', resourceType: 'student', resourceId: studentId, studentId });
      }
      return rows;
    });
  }

  async availability(ctx: Ctx, sectionId: string) {
    return this.db.tx(ctx, async (c) => {
      const { rows: [s] } = await c.query(
        `SELECT id, capacity, enrolled_count, waitlist_capacity, waitlist_count, status FROM sections WHERE id = $1`,
        [sectionId],
      );
      if (!s) throw new NotFoundException('Section not found');
      return {
        sectionId: s.id,
        status: s.status,
        capacity: s.capacity,
        enrolled: s.enrolled_count,
        seatsLeft: s.capacity - s.enrolled_count,
        waitlistCount: s.waitlist_count,
        waitlistSpotsLeft: s.waitlist_capacity - s.waitlist_count,
      };
    });
  }

  // ───────────────────────── helpers ─────────────────────────

  /** ABAC: students act only on themselves; registrar/IT may act on behalf of anyone. */
  private resolveStudent(ctx: Ctx, requested?: string): string {
    if (!requested || requested === ctx.studentId) {
      if (!ctx.studentId || !ctx.has('registration.self')) throw new ForbiddenException();
      return ctx.studentId;
    }
    if (!ctx.has('registration.any')) throw new ForbiddenException();
    return requested;
  }

  private async findByIdemKey(c: PoolClient, idemKey: string): Promise<EnrollResult | null> {
    const { rows } = await c.query(
      `SELECT e.id, e.status, w.position
         FROM enrollments e LEFT JOIN waitlist_entries w ON w.enrollment_id = e.id
        WHERE e.idempotency_key = $1`,
      [idemKey],
    );
    if (!rows.length) return null;
    return { enrollmentId: rows[0].id, status: rows[0].status, waitlistPosition: rows[0].position ?? null };
  }

  private loadRemaining(ctx: Ctx, sectionId: string): Promise<number> {
    return this.db.tx(ctx, async (c) => {
      const { rows } = await c.query(
        `SELECT (capacity + waitlist_capacity - enrolled_count - waitlist_count) AS remaining
           FROM sections WHERE id = $1`,
        [sectionId],
      );
      if (!rows.length) throw new NotFoundException('Section not found');
      return Math.max(0, Number(rows[0].remaining));
    });
  }
}
