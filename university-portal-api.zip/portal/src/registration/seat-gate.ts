import { Injectable, Logger } from '@nestjs/common';
import { RedisService } from '../common/redis.service';

/**
 * Redis admission gate: a cheap, atomic FILTER in front of Postgres during enrollment spikes.
 * The counter holds "remaining admissible attempts" = seats + waitlist spots still free.
 * It is NOT the source of truth (the guarded UPDATE in Postgres is). Properties:
 *  - TTL'd so any drift heals itself from the database within seconds;
 *  - fails OPEN if Redis is unavailable (Postgres still guarantees correctness);
 *  - invalidated on every drop/promotion.
 */
@Injectable()
export class SeatGate {
  private readonly log = new Logger(SeatGate.name);
  private static readonly TTL_SECONDS = 30;

  // -1 = key missing (caller must load), 0 = full, 1 = admitted (counter decremented)
  private static readonly ADMIT_LUA = `
    local v = redis.call('GET', KEYS[1])
    if not v then return -1 end
    if tonumber(v) <= 0 then return 0 end
    redis.call('DECR', KEYS[1])
    return 1`;

  constructor(private readonly redis: RedisService) {}

  private key(sectionId: string) {
    return `gate:section:${sectionId}`;
  }

  async admit(sectionId: string, loadRemaining: () => Promise<number>): Promise<boolean> {
    try {
      const key = this.key(sectionId);
      let r = (await this.redis.client.eval(SeatGate.ADMIT_LUA, 1, key)) as number;
      if (r === -1) {
        const remaining = await loadRemaining();
        await this.redis.client.set(key, remaining, 'EX', SeatGate.TTL_SECONDS, 'NX');
        r = (await this.redis.client.eval(SeatGate.ADMIT_LUA, 1, key)) as number;
      }
      return r !== 0;
    } catch (err) {
      this.log.warn(`Seat gate unavailable, failing open: ${(err as Error).message}`);
      return true;
    }
  }

  /** The attempt did not consume a seat/waitlist spot (validation failed or tx errored). */
  async release(sectionId: string): Promise<void> {
    try {
      const key = this.key(sectionId);
      if (await this.redis.client.exists(key)) await this.redis.client.incr(key);
    } catch {
      /* TTL will heal it */
    }
  }

  /** Capacity changed (drop, promotion, section edit): force a reload from the database. */
  async invalidate(sectionId: string): Promise<void> {
    await this.redis.client.del(this.key(sectionId)).catch(() => undefined);
  }
}
